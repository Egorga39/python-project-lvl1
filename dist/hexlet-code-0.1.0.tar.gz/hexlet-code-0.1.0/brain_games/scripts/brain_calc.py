#!/usr/bin/env python3

import brain_games.games.game_calc


def main():
    brain_games.games.game_calc.check_calc()


if __name__ == '__main__':
    main()
