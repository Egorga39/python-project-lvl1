#!/usr/bin/env python

import prompt
import random
name = ''

def welcome_user():
    global name 
    name = prompt.string('May I have your name? ')
    print('Hello, ' + name + '!')
    return name

def test_even(number):
    if number % 2 == 0:
        right_answer = 'yes'
        return right_answer
    else:
        right_answer = 'no'
        return right_answer    

def check_even():
    print('Answer "yes" if the number is even, otherwise answer "no"')
    n = 0
    while n < 3:
        number = random.randrange(100)
        print('Question: ' + str(number))
        answer = input()
        right_answer = test_even(number)
        if answer == right_answer:
            print('Correct!')
            n += 1
        else:
            return print('"{}" is wrong answer ;(. Correct answer was "{}". Let\'s try again, {}!'.format(answer, right_answer, name))
    print('Congratulations, {}!'.format(name))

#welcome_user()

#check_even()
