#!/usr/bin/env python3

import brain_games.games.game_gcd


def main():
    brain_games.games.game_gcd.check_gsd()


if __name__ == '__main__':
    main()
