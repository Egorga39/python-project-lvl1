#!/usr/bin/env python3

import brain_games.games.game_even


def main():
    brain_games.games.game_even.check_even()


if __name__ == '__main__':
    main()
