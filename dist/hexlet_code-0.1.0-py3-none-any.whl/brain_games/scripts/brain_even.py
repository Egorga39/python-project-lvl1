#!/usr/bin/env python

import brain_games.game1

def main():
    brain_games.game1.welcome_user()
    brain_games.game1.check_even()


if __name__ == '__main__':
    main()

