#!/usr/bin/env python3

import brain_games.games.game_prime


def main():
    brain_games.games.game_prime.check_prime()


if __name__ == '__main__':
    main()
