#!/usr/bin/env python3

import brain_games.games.game_progression


def main():
    brain_games.games.game_progression.check_progression()


if __name__ == '__main__':
    main()
